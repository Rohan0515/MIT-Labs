
int main(){
	int a=5;
	int b=10;
	int c=a+b;
	printf("the sum is %d",c);
	return 0;
}
