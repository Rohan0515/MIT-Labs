
# define x 50


//This is a comment
int main()
{


    
    printf("Hello World!\n");
    return 0;
}