
int isArithmeticRelationalLogical(char c)


int isSpecialSymbolKeywordNumConstantStringLiteralIdentifier(char c)


void skipPreprocessorDirectives(const char*str)


