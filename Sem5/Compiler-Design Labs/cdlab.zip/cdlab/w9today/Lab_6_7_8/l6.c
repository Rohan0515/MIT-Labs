#include <stdio.h>
#include <stdlib.h>

int main()
{
	float firstFlo,secondFlo;
    char firstChar;
	double firstDo;
	firstFlo = secondFlo;
	return 0;
}
