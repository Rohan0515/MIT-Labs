#include <stdio.h>
#include <stdlib.h>

int main()
{
	float a, b;
	char c;
	int first, second, third[5];
	double my_do;
	a = b;
	while (a <= b)
	{
		if (second == 5)
		{
			for (b = 0; b >= 66; b = b + 1)
			{
				if (b == 4)
				{
					my_do = 5;
				}
				a = second + 1;
			}
		}
	}
	while (2 > 3)
	{
	}
	if (second != first)
	{
		c = first * second / 50;
	}
	else
	{
		c = 60;
	}
	return 0;
}
