#ifndef __LEXEME_H__
#define __LEXEME_H__
#include "removePreprocess.h"
#include "removeExcess.h"
#include "constants.h"
#include "structs.h"
#include "utils.h"
#include "tables.h"
#include "hash.h"
#include "getNextToken.h"
#endif