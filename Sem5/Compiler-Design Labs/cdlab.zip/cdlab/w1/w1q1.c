#include <stdio.h>
#include <stdlib.h> 
#include<string.h>

int main()
{
    int countline = 0, countchar = 0;
    char c;
    char file_name[100];
    FILE *fptr;

    printf("enter the file name\n");
    scanf("%s",file_name);


    fptr = fopen(file_name, "r");
    if(fptr == NULL)
    {
        printf("Cant Open File!\n");
        exit(0);
    }



    c = getc(fptr);
    while(c != EOF)
    { 
        if(c == '\n')
            countline++;
        else if(c != ' ' && c != '\n')
            countchar++;
        c = getc(fptr);
     }
    if(countchar > 0)
        countline++;
    printf("Total Number of Lines: %d\n", countline);
    printf("Total Number of Characters: %d\n", countchar);
    return 0;
}