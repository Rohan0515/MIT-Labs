main(){
int a,b;a=b;
a=10;
}
